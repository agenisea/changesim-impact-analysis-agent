"use client"

import React from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle, Target } from "lucide-react"
import { ImpactResult as LegacyImpactResultType } from "@/types/impact"
import { ImpactResult as NewImpactResultType } from "@/types/impact-result"
import { ImpactArtifact } from "@/components/impact/impact-artifact"
import { ArtifactCard } from "@/components/impact/artifact-card"

interface ImpactResultWithArtifactProps {
  result: LegacyImpactResultType | null
  onRegenerate?: () => void
}


function LegacyTabView({ result, onRegenerate }: { result: LegacyImpactResultType; onRegenerate?: () => void }) {
  return (
    <div className="space-y-6">
      {/* AI SDK Format Preview */}
      <div>
        <NewArtifactDemo result={result} onRegenerate={onRegenerate} />
      </div>
    </div>
  )
}

function NewArtifactDemo({ result, onRegenerate }: { result: LegacyImpactResultType; onRegenerate?: () => void }) {
  // Create a preview using the summary content from the legacy result
  const createPreviewResult = (): NewImpactResultType | null => {
    if (!result.analysis?.summary) return null

    // Extract summary bullets and convert to simple markdown
    const summaryBullets = result.analysis.summary
      .split('\n')
      .filter(line => line.trim().startsWith('-'))
      .map(bullet => bullet.replace(/^-\s*/, '').trim())
      .filter(Boolean)

    if (summaryBullets.length === 0) return null

    const summaryMarkdown = summaryBullets.map(bullet => `- ${bullet}`).join('\n\n')

    return {
      summary_markdown: summaryMarkdown,
      risk_level: (result.risk?.level === "low" ? "Low" :
                   result.risk?.level === "medium" ? "Medium" :
                   result.risk?.level === "high" ? "High" : "Medium") as "Low" | "Medium" | "High" | "Critical",
      risk_badge_reason: "Enhanced analysis based on existing assessment",
      decision_trace: result.llmDecisionTrace || [
        "Analyzed role-specific impacts",
        "Assessed organizational change factors",
        "Evaluated risk mitigation strategies",
        "Considered implementation timeline"
      ],
      sources: result.llmSources || [],
      meta: {
        timestamp: new Date().toISOString(),
        status: "complete" as const,
        run_id: `preview_${Date.now()}`
      }
    }
  }

  const previewResult = createPreviewResult()

  if (!previewResult) {
    return (
      <ArtifactCard
        title="Enhanced Impact Analysis"
        subtitle="No summary available"
        status="complete"
      >
        <p className="text-slate-600 dark:text-slate-400 text-center py-8">
          No summary content available to preview the AI SDK format.
        </p>
      </ArtifactCard>
    )
  }

  return (
    <ImpactArtifact
      data={previewResult}
      onRegenerate={onRegenerate}
      onShare={() => console.log("Share clicked")}
      showVariants={false}
      showActions={false}
      role={result.role}
      riskFactors={result.risk?.reasons || []}
      showHighRiskNotice={result.risk?.level === "high"}
      proposedChange={result.changeText}
    />
  )
}

export function ImpactResultWithArtifact({ result, onRegenerate }: ImpactResultWithArtifactProps) {
  return (
    <Card className="shadow-lg border-0 bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-amber-600" />
          Impact Analysis
        </CardTitle>
        <CardDescription>Predicted impacts for the specified role</CardDescription>
      </CardHeader>
      <CardContent>
        {!result && (
          <div className="text-center py-12 text-slate-500 dark:text-slate-400">
            <Target className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>Enter a role and change description to see the impact analysis</p>
          </div>
        )}

        {result && (
          <LegacyTabView result={result} onRegenerate={onRegenerate} />
        )}
      </CardContent>
    </Card>
  )
}