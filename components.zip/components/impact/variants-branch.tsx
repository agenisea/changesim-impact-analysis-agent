import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import ReactMarkdown from "react-markdown"
import remarkGfm from "remark-gfm"

interface Variant {
  label: string
  markdown: string
}

interface VariantsBranchProps {
  variants: Variant[]
}

export function VariantsBranch({ variants }: VariantsBranchProps) {
  if (!variants || variants.length === 0) {
    return null
  }

  // Use the first variant as default
  const defaultValue = variants[0]?.label.toLowerCase().replace(/\s+/g, '-') || 'variant-0'

  return (
    <div className="space-y-3">
      <h4 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
        Alternative Perspectives
      </h4>

      <Tabs defaultValue={defaultValue} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          {variants.map((variant, index) => {
            const value = variant.label.toLowerCase().replace(/\s+/g, '-')
            return (
              <TabsTrigger
                key={index}
                value={value}
                className="text-xs"
              >
                {variant.label}
              </TabsTrigger>
            )
          })}
        </TabsList>

        {variants.map((variant, index) => {
          const value = variant.label.toLowerCase().replace(/\s+/g, '-')
          return (
            <TabsContent key={index} value={value} className="mt-4">
              <div className="prose prose-sm max-w-none dark:prose-invert prose-headings:text-slate-900 dark:prose-headings:text-slate-100 prose-p:text-slate-700 dark:prose-p:text-slate-300 prose-li:text-slate-700 dark:prose-li:text-slate-300 prose-strong:text-slate-900 dark:prose-strong:text-slate-100">
                <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg p-4 border border-slate-200 dark:border-slate-700">
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>
                    {variant.markdown}
                  </ReactMarkdown>
                </div>
              </div>
            </TabsContent>
          )
        })}
      </Tabs>
    </div>
  )
}